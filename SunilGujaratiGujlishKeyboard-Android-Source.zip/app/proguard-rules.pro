# Sunil Gujarati Gujlish Keyboard ProGuard Rules
-keep class com.sunil.gujlishkeyboard.** { *; }
