package com.sunil.gujlishkeyboard.engine

/**
 * Sunil Gujarati-to-Gujlish Transliteration Engine (Kotlin)
 * 
 * Accurately transliterates Gujarati script to Roman Gujarati (Gujlish).
 * Implements general Gujarati phonetic rules:
 * - Multi-character conjuncts matched as Unicode string sequences before single consonants
 * - Inherent schwa /ə/ ('a') on consonants
 * - Word-final schwa deletion (e.g. કમળ -> kamal, ઘર -> ghar, રમત -> ramat)
 * - Medial unstressed schwa deletion in 4-syllable compounds (e.g. સરકસ -> sarkas)
 * - Matra vowel replacement (e.g. કેમ -> kem, દીવો -> divo, દૂધ -> dudh)
 * - Virama / Halant conjunct cluster formation without vowels (e.g. ન્યાય -> nyay)
 * - Anusvara contextual nasalization (e.g. મારું -> maru, પતંગ -> patang, સંબંધ -> sambandh)
 * - Independent vowels and Gujarati numerals
 */
object GujaratiTransliterationEngine {

    // Multi-character conjuncts and ligatures (matched first as string prefixes)
    val CONJUNCTS: List<Pair<String, String>> = listOf(
        "ક્ષ" to "ksh", // \u0A95\u0ACD\u0AB7
        "જ્ઞ" to "gn",  // \u0A9C\u0ACD\u0A9E
        "શ્ર" to "shr", // \u0AB6\u0ACD\u0AB0
        "ત્ર" to "tr",  // \u0AA4\u0ACD\u0AB0
        "દ્વ" to "dv",  // \u0AA6\u0ACD\u0AB5
        "દ્ય" to "dy",  // \u0AA6\u0ACD\u0AAF
        "હ્મ" to "hm"   // \u0AB9\u0ACD\u0Aae
    )

    // Single-character Gujarati consonants (valid 16-bit Char literals)
    val CONSONANTS: Map<Char, String> = mapOf(
        'ક' to "k",
        'ખ' to "kh",
        'ગ' to "g",
        'ઘ' to "gh",
        'ઙ' to "ng",
        'ચ' to "ch",
        'છ' to "chh",
        'જ' to "j",
        'ઝ' to "z",
        'ઞ' to "ny",
        'ટ' to "t",
        'ઠ' to "th",
        'ડ' to "d",
        'ઢ' to "dh",
        'ણ' to "n",
        'ત' to "t",
        'થ' to "th",
        'દ' to "d",
        'ધ' to "dh",
        'ન' to "n",
        'પ' to "p",
        'ફ' to "ph",
        'બ' to "b",
        'ભ' to "bh",
        'મ' to "m",
        'ય' to "y",
        'ર' to "r",
        'લ' to "l",
        'વ' to "v",
        'શ' to "sh",
        'ષ' to "sh",
        'સ' to "s",
        'હ' to "h",
        'ળ' to "l"
    )

    val VOWELS: Map<Char, String> = mapOf(
        'અ' to "a",
        'આ' to "aa",
        'ઇ' to "i",
        'ઈ' to "ee",
        'ઉ' to "u",
        'ઊ' to "oo",
        'ઋ' to "ru",
        'એ' to "e",
        'ઐ' to "ai",
        'ઓ' to "o",
        'ઔ' to "au"
    )

    val MATRAS: Map<Char, String> = mapOf(
        'ા' to "a",
        'િ' to "i",
        'ી' to "i",
        'ુ' to "u",
        'ૂ' to "u",
        'ૃ' to "ru",
        'ૄ' to "roo",
        'ે' to "e",
        'ૈ' to "ai",
        'ો' to "o",
        'ૌ' to "au"
    )

    val DIGITS: Map<Char, String> = mapOf(
        '૦' to "0",
        '૧' to "1",
        '૨' to "2",
        '૩' to "3",
        '૪' to "4",
        '૫' to "5",
        '૬' to "6",
        '૭' to "7",
        '૮' to "8",
        '૯' to "9"
    )

    const val VIRAMA: Char = '્'
    const val ANUSVARA: Char = 'ં'
    const val VISARGA: Char = 'ઃ'
    const val AVAGRAHA: Char = 'ઽ'

    // Proper noun casing conventions
    private val PROPER_NOUNS: Map<String, String> = mapOf(
        "સુનીલ" to "Sunil",
        "સુનિલ" to "Sunil",
        "ગુજરાત" to "Gujarat",
        "ગુજરાતી" to "Gujarati",
        "ગુજલિશ" to "Gujlish",
        "ભારત" to "Bharat"
    )

    /**
     * Transliterates a single Gujarati word/token using general phonetic rules.
     */
    fun transliterateWord(word: String): String {
        val clean = word.trim()
        if (clean.length == 0) return ""

        PROPER_NOUNS[clean]?.let { return it }

        val chars = clean.toCharArray()
        val n = chars.size
        val sb = StringBuilder()

        var i = 0
        while (i < n) {
            // Check multi-character conjuncts first
            var matchedConjunct = false
            for (pair in CONJUNCTS) {
                val conj = pair.first
                val romanBase = pair.second

                if (clean.startsWith(conj, i)) {
                    val nextIdx = i + conj.length
                    val nextCh = if (nextIdx < n) chars[nextIdx] else null
                    val nextNextCh = if (nextIdx + 1 < n) chars[nextIdx + 1] else null

                    // Case A: Followed by Virama (halant)
                    if (nextCh == VIRAMA) {
                        sb.append(romanBase)
                        i = nextIdx + 1
                    }
                    // Case B: Followed by Matra
                    else if (nextCh != null && MATRAS.containsKey(nextCh)) {
                        sb.append(romanBase)
                        sb.append(MATRAS[nextCh]!!)
                        i = nextIdx + 1

                        if (nextNextCh == ANUSVARA) {
                            val afterAnusvara = if (i < n) chars[i] else null
                            if (afterAnusvara != null && CONSONANTS.containsKey(afterAnusvara)) {
                                sb.append("n")
                            }
                            i++
                        }
                    }
                    // Case C: Followed directly by Anusvara
                    else if (nextCh == ANUSVARA) {
                        sb.append(romanBase)
                        if (nextNextCh != null && (nextNextCh == 'પ' || nextNextCh == 'ફ' || nextNextCh == 'બ' || nextNextCh == 'ભ' || nextNextCh == 'મ')) {
                            sb.append("am")
                        } else if (nextIdx == n - 1) {
                            sb.append("am")
                        } else {
                            sb.append("an")
                        }
                        i = nextIdx + 1
                    }
                    // Case D: Conjunct without matra -> Inherent schwa rules
                    else {
                        sb.append(romanBase)
                        val isWordFinal = (nextIdx >= n)
                        if (!isWordFinal) {
                            sb.append("a")
                        }
                        i = nextIdx
                    }

                    matchedConjunct = true
                    break
                }
            }

            if (matchedConjunct) {
                continue
            }

            val ch = chars[i]
            val nextCh = if (i + 1 < n) chars[i + 1] else null
            val nextNextCh = if (i + 2 < n) chars[i + 2] else null

            // 1. Independent Vowel
            if (VOWELS.containsKey(ch)) {
                sb.append(VOWELS[ch]!!)
                i++
                continue
            }

            // 2. Gujarati Digit
            if (DIGITS.containsKey(ch)) {
                sb.append(DIGITS[ch]!!)
                i++
                continue
            }

            // 3. Consonant
            if (CONSONANTS.containsKey(ch)) {
                val base = CONSONANTS[ch]!!

                // Case A: Followed by Virama (Halant) -> conjunct consonant without vowel
                if (nextCh == VIRAMA) {
                    sb.append(base)
                    i += 2
                    continue
                }

                // Case B: Followed by a Matra (Dependent Vowel Sign)
                if (nextCh != null && MATRAS.containsKey(nextCh)) {
                    sb.append(base)
                    var matraStr = MATRAS[nextCh]!!

                    // Single-vowel 3-character root word with ા: e.g. ન + ા + મ -> naam, ક + ા + મ -> kaam
                    if (nextCh == 'ા' && i == 0 && n == 3 && CONSONANTS.containsKey(chars[2])) {
                        matraStr = "aa"
                    }

                    sb.append(matraStr)
                    i += 2

                    // Check if followed by Anusvara right after matra (e.g. મારું -> 'u' + ં)
                    if (nextNextCh == ANUSVARA) {
                        val afterAnusvara = if (i < n) chars[i] else null
                        if (afterAnusvara != null && CONSONANTS.containsKey(afterAnusvara)) {
                            sb.append("n")
                        }
                        i++ // consume anusvara
                    }
                    continue
                }

                // Case C: Consonant followed directly by Anusvara (e.g. સં -> san / sam)
                if (nextCh == ANUSVARA) {
                    sb.append(base)
                    val afterAnusvara = nextNextCh
                    if (afterAnusvara != null && (afterAnusvara == 'પ' || afterAnusvara == 'ફ' || afterAnusvara == 'બ' || afterAnusvara == 'ભ' || afterAnusvara == 'મ')) {
                        sb.append("am")
                    } else if (i == n - 2) {
                        sb.append("am")
                    } else {
                        sb.append("an")
                    }
                    i += 2
                    continue
                }

                // Case D: Consonant without matra or virama -> Inherent Schwa /ə/ ('a')
                sb.append(base)
                val isWordFinal = (i == n - 1)

                if (!isWordFinal) {
                    var shouldAddA = true

                    // 4-syllable unstressed medial schwa deletion (e.g. સરકસ -> s-a-r-k-a-s)
                    if (n >= 4 && i == 1 && CONSONANTS.containsKey(chars[0]) && CONSONANTS.containsKey(chars[1]) && CONSONANTS.containsKey(chars[2])) {
                        shouldAddA = false
                    }

                    if (shouldAddA) {
                        sb.append("a")
                    }
                }
                // Word-final schwa deletion applied automatically
                i++
                continue
            }

            // 4. Standalone Anusvara
            if (ch == ANUSVARA) {
                sb.append("n")
                i++
                continue
            }

            // 5. Visarga
            if (ch == VISARGA) {
                sb.append("h")
                i++
                continue
            }

            // 6. Virama without pair
            if (ch == VIRAMA) {
                i++
                continue
            }

            // 7. Non-Gujarati characters (space, punctuation, latin, emojis)
            sb.append(ch)
            i++
        }

        return sb.toString()
    }

    /**
     * Transliterates a full sentence while preserving whitespace, newlines, and punctuation.
     */
    fun transliterate(text: String): String {
        if (text.length == 0) return ""
        val regex = Regex("""([ \t\r\n,.!?:;"'()\[\]{}<>/\\~`@#$%^&*+=|–—\-]+)""")
        val result = StringBuilder()

        var cursor = 0
        while (cursor < text.length) {
            val delimiterMatch = regex.find(text, cursor)
            if (delimiterMatch != null && delimiterMatch.range.first == cursor) {
                result.append(delimiterMatch.value)
                cursor = delimiterMatch.range.last + 1
            } else {
                val nextDelimiterStart = delimiterMatch?.range?.first ?: text.length
                val token = text.substring(cursor, nextDelimiterStart)
                if (token.isNotEmpty()) {
                    result.append(transliterateWord(token))
                }
                cursor = nextDelimiterStart
            }
        }

        return result.toString()
    }
}
