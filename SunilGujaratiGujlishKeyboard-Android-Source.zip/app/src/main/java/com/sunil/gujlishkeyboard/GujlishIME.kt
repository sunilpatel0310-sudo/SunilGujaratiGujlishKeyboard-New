package com.sunil.gujlishkeyboard

import android.content.Context
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import com.sunil.gujlishkeyboard.engine.GujaratiTransliterationEngine

/**
 * Sunil Gujarati Gujlish Keyboard - Android InputMethodService (IME)
 * 
 * Recreates the Google Gboard typing experience on Android devices.
 * Intercepts Gujarati keyboard keypresses, performs rule-based
 * Gujarati-to-Gujlish transliteration in real-time, and commits
 * Romanized English text directly into any Android application's text field.
 */
class GujlishIME : InputMethodService() {

    private lateinit var keyboardRootView: View
    private lateinit var candidateLayout: LinearLayout
    private lateinit var candidateScrollView: HorizontalScrollView

    // Layout Containers
    private lateinit var layoutLettersNormal: LinearLayout
    private lateinit var layoutLettersShifted: LinearLayout
    private lateinit var layoutSymbols: LinearLayout
    private lateinit var layoutSymbolsAlt: LinearLayout
    private lateinit var matraStrip: LinearLayout

    // Shift Key Buttons for state indicator
    private var shiftBtnNormal: Button? = null
    private var shiftBtnShifted: Button? = null

    // State Variables
    private val composingGujarati = StringBuilder()
    private var isShifted = false
    private var isCapsLock = false
    private var lastShiftPressTime = 0L

    private enum class KeyboardState {
        LETTERS,
        LETTERS_SHIFTED,
        SYMBOLS,
        SYMBOLS_ALT
    }
    private var currentState = KeyboardState.LETTERS

    private var vibrator: Vibrator? = null
    private var audioManager: AudioManager? = null

    // Handler for repeat backspace on long press
    private val repeatHandler = Handler(Looper.getMainLooper())
    private var isBackspacePressed = false
    private val backspaceRepeatRunnable = object : Runnable {
        override fun run() {
            if (isBackspacePressed) {
                onBackspaceKey()
                repeatHandler.postDelayed(this, 60)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    override fun onCreateInputView(): View {
        val inflater = LayoutInflater.from(this)
        keyboardRootView = inflater.inflate(R.layout.input_view, null)

        layoutLettersNormal = keyboardRootView.findViewById(R.id.layout_letters_normal)
        layoutLettersShifted = keyboardRootView.findViewById(R.id.layout_letters_shifted)
        layoutSymbols = keyboardRootView.findViewById(R.id.layout_symbols)
        layoutSymbolsAlt = keyboardRootView.findViewById(R.id.layout_symbols_alt)
        matraStrip = keyboardRootView.findViewById(R.id.matra_strip)

        setupKeys(keyboardRootView)
        updateKeyboardVisibility()
        return keyboardRootView
    }

    override fun onCreateCandidatesView(): View {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.candidate_view, null)
        candidateLayout = view.findViewById(R.id.candidate_container)
        candidateScrollView = view.findViewById(R.id.candidate_scroll)
        setCandidatesViewShown(true)
        return view
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        composingGujarati.clear()
        isShifted = false
        isCapsLock = false
        currentState = KeyboardState.LETTERS
        updateKeyboardVisibility()
        updateCandidates()
    }

    override fun onFinishInput() {
        super.onFinishInput()
        commitComposing()
        composingGujarati.clear()
        updateCandidates()
    }

    /**
     * Applies active casing:
     * - Default output is lowercase
     * - One Shift tap capitalizes the first letter of the word
     * - Double-tap Caps Lock capitalizes all letters (UPPERCASE)
     */
    private fun formatGujlishCasing(rawGujlish: String): String {
        if (rawGujlish.isEmpty()) return ""
        return when {
            isCapsLock -> rawGujlish.toUpperCase()
            isShifted -> {
                if (rawGujlish.length == 1) {
                    rawGujlish.toUpperCase()
                } else {
                    rawGujlish.substring(0, 1).toUpperCase() + rawGujlish.substring(1)
                }
            }
            else -> rawGujlish
        }
    }

    /**
     * Handles Gujarati letter input from keyboard
     */
    fun onGujaratiKey(char: String) {
        playFeedback()
        composingGujarati.append(char)

        val rawGujlish = GujaratiTransliterationEngine.transliterateWord(composingGujarati.toString())
        val gujlish = formatGujlishCasing(rawGujlish)

        currentInputConnection?.setComposingText(gujlish, 1)
        updateCandidates()

        // If in shifted vowels/conjuncts layer, return to normal letters layer after typing a shifted char,
        // while preserving isShifted for the active word being composed.
        if (currentState == KeyboardState.LETTERS_SHIFTED && !isCapsLock) {
            currentState = KeyboardState.LETTERS
            updateKeyboardVisibility()
        }
    }

    /**
     * Handles non-Gujarati character / symbol input
     */
    fun onSymbolOrPunctuation(symbol: String) {
        playFeedback()
        commitComposing()
        currentInputConnection?.commitText(symbol, 1)
        if (isShifted && !isCapsLock) {
            isShifted = false
            currentState = KeyboardState.LETTERS
            updateKeyboardVisibility()
        }
        updateCandidates()
    }

    /**
     * Handles spacebar tap: commits current Gujlish word followed by space
     */
    fun onSpaceKey() {
        playFeedback()
        if (composingGujarati.isNotEmpty()) {
            val rawGujlish = GujaratiTransliterationEngine.transliterateWord(composingGujarati.toString())
            val gujlish = formatGujlishCasing(rawGujlish)
            currentInputConnection?.commitText("$gujlish ", 1)
            composingGujarati.clear()
        } else {
            currentInputConnection?.commitText(" ", 1)
        }

        // Return to lowercase after word boundary when shifted
        if (isShifted && !isCapsLock) {
            isShifted = false
            currentState = KeyboardState.LETTERS
            updateKeyboardVisibility()
        }
        updateCandidates()
    }

    /**
     * Handles backspace: removes last character and updates composing transliteration
     */
    fun onBackspaceKey() {
        playFeedback()
        if (composingGujarati.isNotEmpty()) {
            composingGujarati.deleteCharAt(composingGujarati.length - 1)
            if (composingGujarati.isEmpty()) {
                currentInputConnection?.setComposingText("", 0)
                currentInputConnection?.finishComposingText()
            } else {
                val rawGujlish = GujaratiTransliterationEngine.transliterateWord(composingGujarati.toString())
                val gujlish = formatGujlishCasing(rawGujlish)
                currentInputConnection?.setComposingText(gujlish, 1)
            }
            updateCandidates()
        } else {
            currentInputConnection?.deleteSurroundingText(1, 0)
        }
    }

    /**
     * Handles enter key: commits composing text and triggers action/newline
     */
    fun onEnterKey() {
        playFeedback()
        commitComposing()

        val ic = currentInputConnection ?: return
        val currentInfo = currentInputEditorInfo
        val imeAction = currentInfo.imeOptions and EditorInfo.IME_MASK_ACTION

        if (imeAction != EditorInfo.IME_ACTION_NONE && imeAction != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(imeAction)
        } else {
            sendKeyChar('\n')
        }
        updateCandidates()
    }

    /**
     * Handles Shift key toggle with single-tap and double-tap Caps Lock
     * - Default output must be lowercase.
     * - One Shift tap must capitalize the first letter of the next word, then return to lowercase.
     * - Double-tapping Shift must enable Caps Lock.
     * - Tapping Shift again must disable Caps Lock.
     */
    fun onShiftKey() {
        playFeedback()
        val now = System.currentTimeMillis()

        if (isCapsLock) {
            // Tapping Shift again disables Caps Lock
            isCapsLock = false
            isShifted = false
            currentState = KeyboardState.LETTERS
        } else if (isShifted && (now - lastShiftPressTime < 450)) {
            // Double-tapping Shift enables Caps Lock
            isCapsLock = true
            isShifted = false
            currentState = KeyboardState.LETTERS_SHIFTED
        } else if (isShifted) {
            // Tapping Shift again toggles off Shift
            isShifted = false
            isCapsLock = false
            currentState = KeyboardState.LETTERS
        } else {
            // One Shift tap: capitalizes the first letter of the next word
            isShifted = true
            isCapsLock = false
            currentState = KeyboardState.LETTERS_SHIFTED
        }

        lastShiftPressTime = now
        updateKeyboardVisibility()

        // Re-evaluate composing buffer casing if user toggled shift while typing
        if (composingGujarati.isNotEmpty()) {
            val rawGujlish = GujaratiTransliterationEngine.transliterateWord(composingGujarati.toString())
            val gujlish = formatGujlishCasing(rawGujlish)
            currentInputConnection?.setComposingText(gujlish, 1)
            updateCandidates()
        }
    }

    /**
     * Switches to ?123 symbols layout
     */
    fun onSymbolsKey() {
        playFeedback()
        currentState = KeyboardState.SYMBOLS
        updateKeyboardVisibility()
    }

    /**
     * Switches to =< alternate symbols layout
     */
    fun onSymbolsAltKey() {
        playFeedback()
        currentState = KeyboardState.SYMBOLS_ALT
        updateKeyboardVisibility()
    }

    /**
     * Returns to Alphabet letters layout
     */
    fun onLettersKey() {
        playFeedback()
        currentState = if (isShifted || isCapsLock) KeyboardState.LETTERS_SHIFTED else KeyboardState.LETTERS
        updateKeyboardVisibility()
    }

    /**
     * Commits active composing transliteration to the target editor
     */
    private fun commitComposing() {
        if (composingGujarati.isNotEmpty()) {
            val rawGujlish = GujaratiTransliterationEngine.transliterateWord(composingGujarati.toString())
            val gujlish = formatGujlishCasing(rawGujlish)
            currentInputConnection?.commitText(gujlish, 1)
            composingGujarati.clear()
            if (isShifted && !isCapsLock) {
                isShifted = false
                currentState = KeyboardState.LETTERS
                updateKeyboardVisibility()
            }
        }
    }

    /**
     * Updates visibility of keyboard container layouts based on current state
     */
    private fun updateKeyboardVisibility() {
        if (!::layoutLettersNormal.isInitialized) return

        layoutLettersNormal.visibility = if (currentState == KeyboardState.LETTERS) View.VISIBLE else View.GONE
        layoutLettersShifted.visibility = if (currentState == KeyboardState.LETTERS_SHIFTED) View.VISIBLE else View.GONE
        layoutSymbols.visibility = if (currentState == KeyboardState.SYMBOLS) View.VISIBLE else View.GONE
        layoutSymbolsAlt.visibility = if (currentState == KeyboardState.SYMBOLS_ALT) View.VISIBLE else View.GONE

        // Matra strip is only relevant for Gujarati letter modes
        matraStrip.visibility = if (currentState == KeyboardState.LETTERS || currentState == KeyboardState.LETTERS_SHIFTED) {
            View.VISIBLE
        } else {
            View.GONE
        }

        // Shift visual indicators
        shiftBtnNormal?.text = if (isCapsLock) "▲" else "⇧"
        shiftBtnShifted?.text = if (isCapsLock) "▲" else "⬆"
    }

    private val barakhadiMatras = listOf("", "ા", "િ", "ી", "ુ", "ૂ", "ે", "ૈ", "ો", "ૌ", "ં", "ઃ")

    private fun isGujaratiConsonant(c: Char): Boolean {
        val code = c.toInt()
        return (code in 0x0A95..0x0AB9) || code == 0x0AB3
    }

    private fun isGujaratiMatra(c: Char): Boolean {
        val code = c.toInt()
        return (code in 0x0ABE..0x0ACC) || code == 0x0ACD || code == 0x0A82 || code == 0x0A83
    }

    private fun getTrailingConsonantIndex(str: String): Int {
        if (str.isEmpty()) return -1
        var idx = str.length - 1
        while (idx >= 0 && isGujaratiMatra(str[idx])) {
            idx--
        }
        if (idx >= 0 && isGujaratiConsonant(str[idx])) {
            return idx
        }
        return -1
    }

    /**
     * Updates Gboard suggestions strip with transliterated candidates
     * and dynamic Gujarati Barakhadi suggestions based on the active consonant.
     */
    private fun updateCandidates() {
        if (!::candidateLayout.isInitialized) return
        candidateLayout.removeAllViews()

        if (composingGujarati.isEmpty()) {
            val statusView = TextView(this).apply {
                text = "ગુજરાતી → Gujlish"
                setTextColor(0xFF9AA0A6.toInt())
                textSize = 14f
                setPadding(32, 16, 32, 16)
            }
            candidateLayout.addView(statusView)
            return
        }

        val rawGujarati = composingGujarati.toString()
        val rawGujlish = GujaratiTransliterationEngine.transliterateWord(rawGujarati)
        val primaryGujlish = formatGujlishCasing(rawGujlish)

        // 1. Primary Roman Gujlish word suggestion
        if (primaryGujlish.isNotEmpty()) {
            val wordBtn = Button(this, null, android.R.attr.borderlessButtonStyle).apply {
                text = "$primaryGujlish "
                setTextColor(0xFF8AB4F8.toInt())
                textSize = 15f
                isAllCaps = false
                setPadding(24, 8, 24, 8)
                setOnClickListener {
                    currentInputConnection?.commitText("$primaryGujlish ", 1)
                    composingGujarati.clear()
                    if (isShifted && !isCapsLock) {
                        isShifted = false
                        currentState = KeyboardState.LETTERS
                        updateKeyboardVisibility()
                    }
                    updateCandidates()
                }
            }
            candidateLayout.addView(wordBtn)

            val cap = primaryGujlish.substring(0, 1).toUpperCase() + primaryGujlish.substring(1)
            if (cap != primaryGujlish) {
                val capBtn = Button(this, null, android.R.attr.borderlessButtonStyle).apply {
                    text = "$cap "
                    setTextColor(0xFFFFFFFF.toInt())
                    textSize = 15f
                    isAllCaps = false
                    setPadding(20, 8, 20, 8)
                    setOnClickListener {
                        currentInputConnection?.commitText("$cap ", 1)
                        composingGujarati.clear()
                        if (isShifted && !isCapsLock) {
                            isShifted = false
                            currentState = KeyboardState.LETTERS
                            updateKeyboardVisibility()
                        }
                        updateCandidates()
                    }
                }
                candidateLayout.addView(capBtn)
            }
        }

        // 2. Dynamic Gboard-style Barakhadi candidate strip based on active consonant
        val consonantIdx = getTrailingConsonantIndex(rawGujarati)
        if (consonantIdx >= 0) {
            val baseConsonant = rawGujarati[consonantIdx].toString()
            for (matra in barakhadiMatras) {
                val barakhadiChar = "$baseConsonant$matra"
                val barakhadiBtn = Button(this, null, android.R.attr.borderlessButtonStyle).apply {
                    text = barakhadiChar
                    setTextColor(0xFFE8EAED.toInt())
                    textSize = 16f
                    isAllCaps = false
                    setPadding(18, 8, 18, 8)
                    setOnClickListener {
                        playFeedback()
                        val prefix = rawGujarati.substring(0, consonantIdx)
                        composingGujarati.clear()
                        composingGujarati.append(prefix)
                        composingGujarati.append(barakhadiChar)

                        val updatedRaw = composingGujarati.toString()
                        val updatedGujlish = GujaratiTransliterationEngine.transliterateWord(updatedRaw)
                        val formatted = formatGujlishCasing(updatedGujlish)
                        currentInputConnection?.setComposingText(formatted, 1)
                        updateCandidates()
                    }
                }
                candidateLayout.addView(barakhadiBtn)
            }
        }

        // 3. Raw Gujarati script direct commit option
        val gujBtn = Button(this, null, android.R.attr.borderlessButtonStyle).apply {
            text = "$rawGujarati "
            setTextColor(0xFFBDC1C6.toInt())
            textSize = 15f
            isAllCaps = false
            setPadding(20, 8, 20, 8)
            setOnClickListener {
                currentInputConnection?.commitText("$rawGujarati ", 1)
                composingGujarati.clear()
                if (isShifted && !isCapsLock) {
                    isShifted = false
                    currentState = KeyboardState.LETTERS
                    updateKeyboardVisibility()
                }
                updateCandidates()
            }
        }
        candidateLayout.addView(gujBtn)
    }

    private fun playFeedback() {
        // Haptic feedback
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(18)
            }
        } catch (_: Exception) {}

        // Audio feedback
        try {
            audioManager?.playSoundEffect(AudioManager.FX_KEY_CLICK)
        } catch (_: Exception) {}
    }

    /**
     * Wires up all buttons across all layout containers
     */
    private fun setupKeys(root: View) {
        val actionKeyIds = setOf(
            R.id.key_space, R.id.key_space_shifted, R.id.key_space_symbols, R.id.key_space_sym_alt,
            R.id.key_backspace, R.id.key_backspace_shifted, R.id.key_backspace_symbols, R.id.key_backspace_sym_alt,
            R.id.key_enter, R.id.key_enter_shifted, R.id.key_enter_symbols, R.id.key_enter_sym_alt,
            R.id.key_shift, R.id.key_shift_shifted,
            R.id.key_symbols, R.id.key_symbols_from_shift, R.id.key_symbols_from_alt,
            R.id.key_symbols_alt,
            R.id.key_letters_from_sym, R.id.key_letters_from_alt
        )

        // Space keys
        listOf(
            R.id.key_space, R.id.key_space_shifted, R.id.key_space_symbols, R.id.key_space_sym_alt
        ).forEach { id ->
            root.findViewById<View?>(id)?.setOnClickListener { onSpaceKey() }
        }

        // Enter keys
        listOf(
            R.id.key_enter, R.id.key_enter_shifted, R.id.key_enter_symbols, R.id.key_enter_sym_alt
        ).forEach { id ->
            root.findViewById<View?>(id)?.setOnClickListener { onEnterKey() }
        }

        // Shift keys
        shiftBtnNormal = root.findViewById(R.id.key_shift)
        shiftBtnShifted = root.findViewById(R.id.key_shift_shifted)
        shiftBtnNormal?.setOnClickListener { onShiftKey() }
        shiftBtnShifted?.setOnClickListener { onShiftKey() }

        // Backspace keys with repeat on touch & hold
        listOf(
            R.id.key_backspace, R.id.key_backspace_shifted, R.id.key_backspace_symbols, R.id.key_backspace_sym_alt
        ).forEach { id ->
            root.findViewById<View?>(id)?.let { btn ->
                btn.setOnClickListener { onBackspaceKey() }
                btn.setOnTouchListener { _, event ->
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            isBackspacePressed = true
                            repeatHandler.postDelayed(backspaceRepeatRunnable, 400)
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            isBackspacePressed = false
                            repeatHandler.removeCallbacks(backspaceRepeatRunnable)
                        }
                    }
                    false
                }
            }
        }

        // Mode switching keys
        listOf(
            R.id.key_symbols, R.id.key_symbols_from_shift, R.id.key_symbols_from_alt
        ).forEach { id ->
            root.findViewById<View?>(id)?.setOnClickListener { onSymbolsKey() }
        }

        root.findViewById<View?>(R.id.key_symbols_alt)?.setOnClickListener { onSymbolsAltKey() }

        listOf(
            R.id.key_letters_from_sym, R.id.key_letters_from_alt
        ).forEach { id ->
            root.findViewById<View?>(id)?.setOnClickListener { onLettersKey() }
        }

        // Bind all letter, matra, and symbol character buttons systematically
        bindCharacterButtons(root, actionKeyIds)
    }

    private fun bindCharacterButtons(view: View, actionKeyIds: Set<Int>) {
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                bindCharacterButtons(view.getChildAt(i), actionKeyIds)
            }
        } else if (view is Button) {
            if (!actionKeyIds.contains(view.id)) {
                val keyText = view.text?.toString() ?: ""
                if (keyText.isNotEmpty()) {
                    view.setOnClickListener {
                        val firstChar = keyText[0]
                        if (isGujaratiScript(firstChar)) {
                            onGujaratiKey(keyText)
                        } else {
                            onSymbolOrPunctuation(keyText)
                        }
                    }
                }
            }
        }
    }

    private fun isGujaratiScript(c: Char): Boolean {
        val code = c.toInt()
        return code in 0x0A80..0x0AFF
    }
}
