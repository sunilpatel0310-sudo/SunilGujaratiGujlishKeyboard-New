# Sunil Gujarati Gujlish Keyboard - Android Native Project

This directory contains the production-grade Android InputMethodService (IME) source code for **Sunil Gujarati Gujlish Keyboard**.

## How to Build the Real Android APK:

### Option 1: Using Android Studio (Recommended, 2 Minutes)
1. Download the exported project ZIP from this applet (click "Download Android Studio Project (.ZIP)").
2. Unzip the folder on your computer.
3. Open **Android Studio** (Hedgehog, Iguana, Jellyfish, or newer).
4. Click **File > Open** and select the unzipped directory.
5. Let Gradle sync dependencies automatically.
6. Connect your Android phone via USB (with USB Debugging enabled) or start an Android Emulator.
7. Click the green **Run (▶)** button or go to **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
8. The installable `.apk` file will be generated in `app/build/outputs/apk/debug/app-debug.apk`!

### Option 2: Using Command Line (Terminal / Command Prompt)
```bash
# In the project directory:
./gradlew assembleDebug

# Output APK path:
# app/build/outputs/apk/debug/app-debug.apk

# Install directly to connected device:
adb install app/build/outputs/apk/debug/app-debug.apk
```

### Enabling the Keyboard on Android:
1. Open phone **Settings** > **System** > **Languages & input** > **On-screen keyboard** (or **Manage Keyboards**).
2. Enable toggle for **Sunil Gujarati Gujlish Keyboard**.
3. Tap on any chat or text box (e.g., WhatsApp, Messages, Notes).
4. Tap the keyboard switcher icon in the navigation bar and pick **Sunil Gujarati Gujlish Keyboard**.
5. Start typing in Gujarati characters — it will automatically output pure Roman Gujarati (Gujlish)!
